/* ANSI proto header for mt.c */

public void seedMT(unsigned long seed);
public unsigned long randomMT(void);
