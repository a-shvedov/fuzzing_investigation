/*
  just a blank include for debugging defines

  just echo '#define VAR' >> debug.h to enable the option
*/
