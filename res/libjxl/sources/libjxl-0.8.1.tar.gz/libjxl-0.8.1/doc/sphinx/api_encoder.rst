Encoder API - ``jxl/encode.h``
==============================

.. doxygengroup:: libjxl_encoder
   :members:
   :private-members:
