Decoder API - ``jxl/decode.h``
==============================

.. doxygengroup:: libjxl_decoder
   :members:
   :private-members:
